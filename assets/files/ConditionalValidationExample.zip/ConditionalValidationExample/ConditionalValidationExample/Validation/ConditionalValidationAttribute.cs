using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Reflection;

namespace ConditionalValidationExample.Validation
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property)]
    public class ConditionalValidationAttribute : Attribute
    {
        #region Fields

        private readonly MethodInfo _methodInfo;
        private readonly bool _isSingleArgumentMethod;
        private readonly Type _valuesType;

        #endregion

        #region Properties

        public string ErrorMessage { get; set; }
        public string Method { get; private set; }
        public Type ValidatorType { get; private set; }

        #endregion

        #region Constructor

        /// <summary>
        /// Performs validation by calling a specified static method with one of the following signatures:
        /// ValidationResult Method(object value)
        /// ValidationResult Method(object value, object context)
        /// The value parameter may be strongly typed, if a process passes a value of a different type, type conversion will be attempted.
        /// </summary>
        /// <param name="validatorType">The type that contains the method that performs custom validation.</param>
        /// <param name="method">The method that performs custom validation.</param>
        public ConditionalValidationAttribute(Type validatorType, string method)
        {
            if (string.IsNullOrEmpty(method))
                throw new ArgumentException("method");

            Method = method;
            ValidatorType = validatorType;
            // Find a matching method - if multiple matching methods, pick the one with 2 parameters.
            var methods = from m in validatorType.GetMethods(BindingFlags.Public | BindingFlags.Static)
                          let p = m.GetParameters().Length
                          where m.Name == method &&
                                m.ReturnType == typeof(ValidationResult) &&
                                (p == 1 || p == 2)
                          orderby p descending
                          select m;

            if (methods.Count() == 0)
                throw new InvalidOperationException(string.Format("No method '{0}' found in class '{1}' with a valid signature.", method, validatorType));
            _methodInfo = methods.First();
            var parameters = _methodInfo.GetParameters();
            _isSingleArgumentMethod = parameters.Length == 1;
            _valuesType = parameters[0].ParameterType;
        }

        #endregion

        #region Public Methods

        public ValidationResult IsValid(object value, object context)
        {
            object convertedValue;
            var info = _methodInfo;
            if (!TryConvertValue(value, out convertedValue))
            {
                throw new InvalidOperationException(
                    string.Format(
                        "Unable to convert value from type {0} to type {1}",
                        (value != null) ? value.GetType().ToString() : "null",
                        _valuesType));
            }
            try
            {
                var parameters = _isSingleArgumentMethod ? new[] { convertedValue } : new[] { convertedValue, context };
                var result = (ValidationResult)info.Invoke(null, parameters);
                if (result != ValidationResult.Success && result.ErrorMessage == null)
                    result.ErrorMessage = ErrorMessage;
                return result;
            }
            catch (TargetInvocationException exception)
            {
                if (exception.InnerException != null)
                {
                    throw exception.InnerException;
                }
                throw;
            }
        }

        #endregion

        #region Private Methods

        private bool TryConvertValue(object value, out object convertedValue)
        {
            convertedValue = null;
            Type conversionType = _valuesType;
            if (value == null)
            {
                return (!conversionType.IsValueType || (conversionType.IsGenericType && (conversionType.GetGenericTypeDefinition() == typeof(Nullable<>))));
            }
            if (conversionType.IsAssignableFrom(value.GetType()))
            {
                convertedValue = value;
                return true;
            }
            try
            {
                convertedValue = Convert.ChangeType(value, conversionType, CultureInfo.CurrentCulture);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
            catch (InvalidCastException)
            {
                return false;
            }
            catch (NotSupportedException)
            {
                return false;
            }
        }

        #endregion
    }
}