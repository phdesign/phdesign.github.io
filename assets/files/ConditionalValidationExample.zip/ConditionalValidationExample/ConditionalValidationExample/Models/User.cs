﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using ConditionalValidationExample.Validation;

namespace ConditionalValidationExample.Models
{
    public class User : ModelBase
    {
        [Required]
        public int UserId { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string Country { get; set; }
        [Required]
        [ConditionalValidation(typeof(User), "ValidateState")]
        public string State { get; set; }

        public static ValidationResult ValidateState(string state, object context)
        {
            var user = context as User;
            if (user == null)
                throw new ArgumentException("context is not of type User", "context");

            var australianStates = new[] {"VIC", "TAS", "NSW", "ACT", "QLD", "NT", "WA", "SA"};
            if (user.Country.Equals("Australia", StringComparison.CurrentCultureIgnoreCase))
            {
                if (!australianStates.Contains(state, StringComparer.CurrentCultureIgnoreCase))
                    return new ValidationResult("Not a valid Australian state", new[] {"State"});
            }
            return ValidationResult.Success;
        }
    }
}