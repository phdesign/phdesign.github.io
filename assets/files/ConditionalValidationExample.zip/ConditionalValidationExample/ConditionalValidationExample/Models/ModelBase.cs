﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web;
using ConditionalValidationExample.Validation;

namespace ConditionalValidationExample.Models
{
    public abstract class ModelBase : IValidatableObject
    {
        /// <summary>
        /// The list of validations for each property
        /// </summary>
        protected Dictionary<string, ConditionalValidationAttribute[]> Validations { get; private set; }

        protected ModelBase()
        {
            Validations = (from property in GetType().GetProperties()
                           let validations = GetValidations(property)
                           where validations.Length > 0
                           select new {PropertyName = property.Name, Validations = validations})
                .ToDictionary(a => a.PropertyName, a => a.Validations);
        }

        /// <summary>
        /// Validates all ConditionalValidationAttributes
        /// </summary>
        /// <param name="validationContext"></param>
        /// <returns></returns>
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            return from property in Validations
                   from validator in property.Value
                   select validator.IsValid(GetPropertyValue(property.Key), this)
                   into validationResult
                   where validationResult != ValidationResult.Success
                   select validationResult;
        }

        #region Private & Protected Methods

        /// <summary>
        /// Gets the validation attributes attached to a property.
        /// </summary>
        /// <param name="property">The property.</param>
        /// <returns>An array of validation attributes.</returns>
        private static ConditionalValidationAttribute[] GetValidations(PropertyInfo property)
        {
            return property.GetCustomAttributes(typeof(ConditionalValidationAttribute), true)
                .Cast<ConditionalValidationAttribute>().ToArray();
        }

        /// <summary>
        /// Gets the value for a property.
        /// </summary>
        /// <param name="propertyName">The property name.</param>
        /// <returns>The value of the property as an object.</returns>
        protected object GetPropertyValue(string propertyName)
        {
            try
            {
                return GetType().GetProperty(propertyName).GetValue(this, null);
            }
            catch (TargetInvocationException exception)
            {
                if (exception.InnerException != null)
                    throw exception.InnerException;
                throw;
            }
        }

        #endregion
    }
}