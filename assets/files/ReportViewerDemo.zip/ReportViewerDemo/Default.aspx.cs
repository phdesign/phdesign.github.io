using System;
using System.Web;
using Microsoft.Reporting.WebForms;
using System.IO;
using System.Text;
using System.Collections.Generic;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if (Page.IsPostBack)
		{
			LocalReport report = new LocalReport();
			string reportName = "CompletionCertificate";
			string deviceInfo =
			  "<DeviceInfo>" +
			  "  <OutputFormat>EMF</OutputFormat>" +
			  "  <PageWidth>8.5in</PageWidth>" +
			  "  <PageHeight>11in</PageHeight>" +
			  "  <MarginTop>0.25in</MarginTop>" +
			  "  <MarginLeft>0.25in</MarginLeft>" +
			  "  <MarginRight>0.25in</MarginRight>" +
			  "  <MarginBottom>0.25in</MarginBottom>" +
			  "</DeviceInfo>";
			Warning[] warnings;
			string[] streamids;
			string mimeType;
			string encoding;
			string extension;

			report.ReportPath = "Report.rdlc";
			report.DataSources.Add(new ReportDataSource("Person", PersonDataSource.GetPerson(txtTitle.Text, txtFirstName.Text, txtLastName.Text)));
			byte[] bytes = report.Render("PDF", deviceInfo, out mimeType, out encoding, out extension, out streamids, out warnings);

			Response.Clear();
			Response.ContentType = mimeType;
			Response.AddHeader("Content-Disposition", "attachment; filename=" + reportName + "." + extension);
			Response.OutputStream.Write(bytes, 0, bytes.Length);
			Response.End();
		}
    }
}
