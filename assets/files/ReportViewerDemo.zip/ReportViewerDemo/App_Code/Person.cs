using System;
using System.Collections.Generic;

/// <summary>
/// The business object we want to use in our report.
/// </summary>
public class Person
{
	/// <summary>
	/// Some fields to hold information about this person.
	/// </summary>
	private string _title;
	private string _firstName;
	private string _lastName;

	/// <summary>
	/// The person properties are only able to be set at instantiation.
	/// After the object is created the properties are read only.
	/// </summary>
	public string Title
	{
		get { return _title; }
	}

	public string FirstName
	{
		get { return _firstName; }
	}

	public string LastName
	{
		get { return _lastName; }
	}

	/// <summary>
	/// The person constructor.
	/// </summary>
	/// <param name="title">The person's title</param>
	/// <param name="firstName">Their first name</param>
	/// <param name="lastname">Their last name</param>
	public Person(string title, string firstName, string lastname)
	{
		_title = title;
		_firstName = firstName;
		_lastName = lastname;
	}
}

/// <summary>
/// Creates a data source for our report.
/// </summary>
public class PersonDataSource
{
	/// <summary>
	/// This method creates a new person object and adds them to a new collection that 
	/// can be used as a data source for the report.
	/// </summary>
	/// <returns>A collection of person objects.</returns>
	public static List<Person> GetPerson(string title, string firstName, string lastName)
	{
		List<Person> people = new List<Person>();
		people.Add(new Person(title, firstName, lastName));
		return people;
	}
}
